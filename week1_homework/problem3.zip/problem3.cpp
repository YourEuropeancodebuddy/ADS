#include <iostream>
#include "problem3.h"

int main() {
    LinkedList<int> myList;

    // Adding elements to the list
    myList.addToEnd(1);
    myList.addToEnd(2);
    myList.addToFront(3);
    myList.addToFront(4);

    // Printing elements
    std::cout << "First element: " << myList.getFirst() << std::endl;
    std::cout << "Last element: " << myList.getLast() << std::endl;

    // Removing elements
    std::cout << "Removed first element: " << myList.removeFromFront() << std::endl;
    std::cout << "Removed last element: " << myList.removeFromEnd() << std::endl;

    // Getting size of list
    std::cout << "Size of list: " << myList.getSize() << std::endl;

    // Checking if list is empty
    std::cout << "Is list empty? " << (myList.isEmpty() ? "Yes" : "No") << std::endl;

    return 0;
}
