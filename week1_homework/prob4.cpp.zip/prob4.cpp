#include<vector>
#include<iostream>
#include<cstdlib>

int main(){
    int size = 0;
   std::string input;
    std::vector<std::string>stringobj;
    while(std::cin>>input){
        if(input == "END"){
            break;
        }
        else{
        stringobj.push_back(input);
        size++;
        }
    }
    std::cout<<" the elements entered in the vector "<<std::endl;
    for (int i = 0; i<size; i++){
        std::cout<<" "<< stringobj[i];
    }
    std::cout<<std::endl;
    bool first = true;
    std::vector<std::string>::iterator it;
    for(it = stringobj.begin();it != stringobj.end(); it++){
        if(!first){
            std::cout<<", ";
        }
        std::cout<<*it;
        first = false;
    }

}



